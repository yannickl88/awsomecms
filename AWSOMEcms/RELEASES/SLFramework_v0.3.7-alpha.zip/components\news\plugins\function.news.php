<?php
function smarty_function_news($params, &$smarty)
{
    include_once Config::get('websiteroot', '.').'/components/news/class.NewsComponent.inc';
    $newsComponent = new NewsComponent('news');

    $smarty->assign("news", $newsComponent->select());

    return $smarty->fetch("news/news.tpl");
}