INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('edit', '/admin/page/', '{form component=''page'' form=''edit''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('add', '/admin/page/', '{form component=''page'' form=''add''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('delete', '/admin/page/', '{form component=''page'' form=''delete''}', '2009-09-12 00:31:07');
