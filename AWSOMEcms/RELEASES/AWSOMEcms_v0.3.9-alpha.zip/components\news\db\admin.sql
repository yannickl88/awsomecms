INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('admin', '/admin/news/', '{form component=''news'' form=''admin''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('add', '/admin/news/', '{form component=''news'' form=''add''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('delete', '/admin/news/', '{form component=''news'' form=''delete''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('edit', '/admin/news/', '{form component=''news'' form=''edit''}', '2009-09-12 00:31:07');
