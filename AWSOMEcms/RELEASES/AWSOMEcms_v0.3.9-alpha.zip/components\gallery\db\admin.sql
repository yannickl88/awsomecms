INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('add', '/admin/gallery/', '{form component=''gallery'' form=''add''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('edit', '/admin/gallery/', '{form component=''gallery'' form=''edit''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('delete', '/admin/gallery/', '{form component=''gallery'' form=''delete''}', '2009-09-12 00:31:07');
INSERT INTO `pages` (`page_name`, `page_location`, `page_template`, `page_timestamp`) VALUES('admin', '/admin/gallery/', '{form component=''gallery'' form=''admin''}', '2009-09-12 00:31:07');
