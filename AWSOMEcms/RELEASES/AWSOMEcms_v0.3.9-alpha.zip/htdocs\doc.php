<?php
session_start();

global $websiteroot, $start;

$start = microtime(true);
$websiteroot = dirname(__FILE__);

require_once '../core/init.inc';

function parseInfoFile($file, $component)
{
    if(file_exists($file))
    {
        $data = file($file);
        $result = array(
            "desc" => "",
            "tags" => array(),
            "modifiers" => array(),
        );
        
        $currentTextType = 0;
        $currentLine = 0;
        
        while($currentLine < count($data))
        {
            $line = $data[$currentLine];
            $currentLine++;
            
            if(trim($line) == strtoupper($component->component_name.":"))
            {
                $currentTextType = 1;
                continue;
            }
            if(trim($line) == strtoupper("TAGS:"))
            {
                $currentTextType = 2;
                
                continue;
            }
            if(trim($line) == strtoupper("MODIFIERS:"))
            {
                $currentTextType = 3;
                continue;
            }
            
            if($currentTextType == 1)
            {
                $result['desc'] .= $line;
            }
            if($currentTextType == 2)
            {
                $tag = array(
                    "name" => trim($line),
                    "params" => array(),
                );
                
                while($data[$currentLine][0] == " ")
                {
                    $data[$currentLine] = trim($data[$currentLine]);
                    
                    if(strpos($data[$currentLine], " ") !== false)
                    {
                        $line = substr($data[$currentLine], 0, strpos($data[$currentLine], " "));
                        $desc = substr($data[$currentLine], strpos($data[$currentLine], " ")+1);
                    }
                    else
                    {
                        $line = $data[$currentLine];
                        $desc = "";
                    }
                    $currentLine++;
                    
                    $line2 = explode(",",trim($data[$currentLine]));
                    $currentLine++;
                    
                    $tag['params'][] = array(array(substr(trim($line), 1, -1), $desc), array(ucfirst($line2[0]), trim($line2[1])));
                }
                $result['tags'][] = $tag;
            }
            if($currentTextType == 3)
            {
                $tag = array(
                    "name" => trim($line),
                    "params" => array(),
                );
                
                while($data[$currentLine][0] == " ")
                {
                    $data[$currentLine] = trim($data[$currentLine]);
                    
                    if(strpos($data[$currentLine], " ") !== false)
                    {
                        $line = substr($data[$currentLine], 0, strpos($data[$currentLine], " "));
                        $desc = substr($data[$currentLine], strpos($data[$currentLine], " ")+1);
                    }
                    else
                    {
                        $line = $data[$currentLine];
                        $desc = "";
                    }
                    $currentLine++;
                    
                    $line2 = explode(",",trim($data[$currentLine]));
                    $currentLine++;
                    
                    $tag['params'][] = array(array(substr(trim($line), 1, -1), $desc), array(ucfirst($line2[0]), trim($line2[1])));
                }
                $result['modifiers'][] = $tag;
            }
        }
        
        $result['desc'] = trim($result['desc']);
        
        return $result;
    }
    else
    {
        return array();
    }
}

$components = Config::getInstance()->getComponenets();
?>
<html>
    <head>
        <title>Documentation</title>
        <script type="text/javascript" src="http://www.google.com/jsapi"></script>
        <script type="text/javascript">
            // <![CDATA[ 
            // Load jQuery
            google.load("jquery", "1.3.1", {uncompressed:false});
            google.load("jqueryui", "1.5.3");
            // ]]> 
        </script>
        <style>
            pre {
                word-wrap: break-word;
                white-space: pre-wrap;
                margin: 4px;
            }
            ul {
                margin: 0;
            }
        </style>
    </head>
    <body style="margin: 0; padding: 0;">
        <div style="float: left; width: 200px; height: 100%; overflow: auto;">
            <div style="margin: 4px;">
                Components
                <ul>
<?php
    foreach($components as $component)
    {
        echo "                    <li><a href='#'>{$component->component_name}</a></li>\n";
    }
?>
                </ul>
            </div>
        </div>
        <div style="margin-left: 200px; height: 100%; overflow: auto;">
<?php
    foreach($components as $component)
    {
        echo "            <div id=\"comp_{$component->component_name}\" style=\"display: block;\">\n";
        
        //let's parse that info file
        $data = parseInfoFile("{$component->component_path}/{$component->component_name}.info", $component);
        
        echo "            <h1>".ucfirst($component->component_name)."</h1>\n";
        echo "            <p>".$data['desc']."</p>\n";
        if(count($data['tags']) > 0)
        {
            echo "            <h2>Tags:</h2>\n";
            
            foreach($data['tags'] as $tag)
            {
                echo "            <b>{$tag['name']}</b><br />\n";
                echo "            Parameters:<br />\n";
                echo "            <ul>\n";
                foreach($tag['params'] as $param)
                {
                    echo "                <li>";
                    if($param[1][1] == "optional")
                    {
                        echo "[ ";
                    }
                    echo "<i style='font-size: 0.8em;'>{$param[1][0]}</i> {$param[0][0]}";
                    if($param[1][1] == "optional")
                    {
                        echo " ]";
                    }
                    echo "<br/>".$param[0][1];
                    echo "</li>\n";
                }
                echo "            </ul>\n";
            }
        }
        if(count($data['modifiers']) > 0)
        {
            echo "            <h2>Modifiers:</h2>\n";
        }
        echo "            </div>\n";
    }
?>

            </div>
        </div>
    </body>
</html>